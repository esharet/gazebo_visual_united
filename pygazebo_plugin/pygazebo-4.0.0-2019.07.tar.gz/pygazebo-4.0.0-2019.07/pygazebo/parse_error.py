class ParseError(RuntimeError):
    pass
