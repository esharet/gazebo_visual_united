.. :changelog:

History
-------

3.0.0-2014.1 (2014-07-04)
+++++++++++++++++++++++++

* Switch from eventlet to trollius/asyncio, for better compatibility
  with other event loops and future python versions.
* Update to gazebo 3.0.0
  
2.2.1-2014.2 (2014-06-04)
+++++++++++++++++++++++++

* Properly support sending and receiving large messages.

2.2.1-2014.1 (2014-02-11)
+++++++++++++++++++++++++

* First release on PyPI.
